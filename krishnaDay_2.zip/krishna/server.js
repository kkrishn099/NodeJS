//building a node server using http

var fs = require('fs')
var https = require('https')
/*http.createServer((req,res)=>{
    res.writeHead(200,{'Content-Typr':'text/plain'})
    
    if(req.url === './lib/file.txt'){
        fs.createReadStream(__dirname+'.lib/node.html').pipe(res)
    }else{
        res.end('The Responce ended')
    }
}).listen(3000)//(process.env.PORT,process.env.IP)
console.log('server listenting on port 3000')
console.log(`${process.env.IP}`)*/



var options ={
    hostname:'en.wikipedia.org',
    port:443,
    path:'/wiki/George_Washington',
    method:'GET'
}
//en-wikipedia.org/wiki/George_Washington
var req = https.request(options,(res)=>{
    var responseBody =''
    console.log('Response from the server')
    console.log(`Server status  : ${res.statusCode}`)
    console.log(`Response Header : ${res.headers}`)
    res.setEncoding('UTF-8')
    res.once('data',(chunk)=>{
        console.log(chunk)
    })
    
   
    
    res.on('data',(chunk)=>{
        console.log(`-----DATA-----${chunk.length}`)
        responseBody += chunk
    })
    
     res.on('end',(chunk)=>{
        fs.writeFile('./lib/george.html',responseBody ,(err)=>{
            if(err){
                throw(err)
            }
            console.log('Read the data from the file......')
        })
       
     })
      res.on('error',(err)=>{
        console.log('-----Error-----'+err.message)
        
    })
      
     
    
})
req.end();