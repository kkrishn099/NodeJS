//DAY-2


var fs =require('fs')
var stream = fs.createReadStream('./lib/file.txt','UTF-8')
var data =' '
stream.once('data',function(){
    console.log('\n\n Reading stated ....\n\n')
})
stream.on('data',function(chunk){
    process.stdout.write(`>>>Data>>>> ${chunk} and Lenght is ${chunk.length}`)
    data += chunk
})
stream.on('end',function(){
    console.log('\n\n Reading Completed ....\n\n')
})