//readingData.js
var fs = require('fs')
// reading file sync

/*var files = fs.readdirSync('./lib')

console.log(files)*/

//reading file name async
/*
fs.readdir('lib',function(err,files)
          {
    if(err)
        {
            throw err
        }
    console.log(files)
})
    */

// reading file contents sync
/*var contents = fs.readFileSync('./lib/file.txt','UTF-8')
console.log(contents)

console.log('Displaying files from lib directory')*/

//reading file contents sync
fs.readFile('./lib/file.txt','UTF-8',function(err,data)
           {
    if(err)
        {
            throw err
        }
    console.log(data)
})