import { Injectable } from '@angular/core';
import { IProductts } from './iproductts';
import {HttpClient} from '@angular/common/http'
import { Observable ,throwError } from 'rxjs';
import{map , tap , catchError} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products :IProductts[]=[]

  private _productUrl='./assets/api/products/products.json'
  constructor(private _httpClient:HttpClient) {

   }

  // getProduct():IProductts[]{
  //   return this.products

  // }
  getProducts():Observable<IProductts[]>{
    console.log(this._httpClient.get<IProductts[]>(this._productUrl))
    return this._httpClient.get<IProductts[]>(this._productUrl)
    .pipe(tap((data)=>console.log('All Data :' +JSON.stringify(data)))
    ,catchError(this.handleError)
    
    
    )
    
    
  }
  getProduct(id:number):Observable<IProductts>{
    return this.getProducts().pipe(
      map((products:IProductts[])=>
      products.find(p=>p.productId===id)
    )
    )
  }
  private handleError(err){
    let errMessage =''
    if(err.error instanceof Error){
      errMessage =`AN error occured :${err.status} eror mesage${err.message }`
      console.log(errMessage + 'THE ERROR ')
      return throwError(errMessage)
    } 
  }
}
