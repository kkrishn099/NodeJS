import { Component, OnInit, Input,OnChanges, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit ,OnChanges {

  @Input()rating :number 
  starWidth:number
  @Output() notify :EventEmitter<string> = new EventEmitter<string>() 



  constructor() { }

  ngOnInit() {
  }
  
  ngOnChanges(){
    this.starWidth=this.rating * 68/5
  }
  onClick(){

    this.notify.emit(`The rating ${this.rating} click`)
  }
  
  

}
