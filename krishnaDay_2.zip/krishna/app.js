var emitter = require('./customEventEmitter')

var e1= new emitter()
e1.on('greet', function()
      {
    console.log('A greeting created')
})

e1.on('greet', function()
     {
    console.log('A second greeting created')
})

e1.emit('greet')
console.log('A simple hello')

