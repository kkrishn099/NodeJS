//emotter.js
//Day-2


var Resource =require('./resource')
//var r = getResource(5)
var r = new Resource(7)
r.on('start',function(){
    console.log('function starded')
})

//var r = getResource(5)
r.on('data',function(d){
    console.log('Receive data....'+d)
})


r.on('end',function(t){
    console.log(`Done with : ${t} data event`)
})

