var fs = require('fs')
var content =`Hello I m gona write......`
/*fs.writeFile('./lib/sample.txt',content.trim(),(err)=>{
    if(err){
        throw(err)
    }
   
})*/
 console.log(`file sample.txt created...`)
 
 /*//appending data to the existing file..
 
 fs.appendFile('./lib/sample.txt','New test appended to sample.txt',(err)=>{
     if(err){
         throw(err)
     }
     console.log('new file is appended')
 })*/
 
 //creating directory 
 if(fs.existsSync('mydir')){
     console.log('directory already exists')
 }else{
 
 fs.mkdir('mydir',(err)=>{
     if(err){
         throw(err)
     }
      console.log('directory created')
 })}