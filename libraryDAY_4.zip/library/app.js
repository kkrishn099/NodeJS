
const express = require('express');
const debug = require('debug')('app');
const chalk = require('chalk');
const path = require('path');
const morgan = require('morgan');

const app = express();
const port = process.env.PORT || 3000;
app.use(morgan('combined'));
app.use(express.static(path.join(__dirname, '/public')));
app.set('views', './src/views');
app.set('view engine', 'ejs');
// app.use('/css',express.static(path.join(__dirname,
// '/node_modules/bootstrap/dist/css/bootstap.css')))
app.get('/', (req, res) => {
  // res.send('Hello from Books library application')
  // res.sendFile(__dirname + '/views/index.html')

  // OR
  // res.sendFile(path.join(__dirname, '/views/index.html'));
 // res.render('index1.ejs', {list:['book1','book2','book3'], title: 'Books - library' });
      res.render(
        'index1' ,{
          nav:[
            {link:'/books',title:'Books'},
            {link:'/authors' ,title:'Author'}
          ],
          title:'Book-Library'
        }
      )
});

app.listen(port, () => {
  debug(`server is listening @ ${chalk.green(port)}`);
});
