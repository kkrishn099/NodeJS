import { Component, OnInit } from '@angular/core';
import {ProductService} from './product.service'
import{ActivatedRoute} from '@angular/router'
import { IProductts } from './iproductts'

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  constructor(private _productService :ProductService ,private _activatedRoute :ActivatedRoute) { }
   pageTitle :'Product - Detail'
   errorMessage :string
   product :IProductts
  ngOnInit() {
    const param =this._activatedRoute.snapshot.paramMap.get('id')
      if(param){
        const _id = +param
         this.getProduct(_id)
      }
  }

  getProduct(id:number){
    this._productService.getProduct(id).subscribe((product)=>this.product
    =product,(error)=>this.errorMessage=<any>error)
  }

}
