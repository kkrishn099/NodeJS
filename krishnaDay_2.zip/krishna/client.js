//day -2
//client.js

var http =require('http')
var fs = require('fs')
console.log('making a request')
/*
var req = http.request('http://nodejs.org/en/',(res)=>{
    console.log(res.statusCode)
    console.log(res.statusMessage)
    res.pipe(process.stdout)
})
req.end()//request function take to parameter url ,callback function
*/

var option={
    host:'www.google.com',
    port:80,
    path:'/',
    method:'GET'
}
var req = http.request(option,(res)=>{
    res.pipe(fs.createWriteStream('./lib/google.html'))
})
req.end()