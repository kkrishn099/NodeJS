//Day-2
//pipe.js
var request = require('request') // it's is third party module so we have to install it --npm install request
var zlib = require('zlib')

var url =request('https://nodejs.org/en/')
var fs = require('fs')

url.pipe(process.stdout)

url.pipe(fs.createWriteStream('./lib/node.html'))

//zlib



url.pipe(zlib.createGzip()).pipe(fs.createWriteStream(('./lib/node.html.gz')))